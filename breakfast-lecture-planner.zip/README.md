# breakfast-lecture-planner
A web application for publishing and managing schedules for breakfasts and lectures.
