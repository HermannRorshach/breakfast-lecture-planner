from django.apps import AppConfig


class CalendarUtilsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'calendar_utils'
